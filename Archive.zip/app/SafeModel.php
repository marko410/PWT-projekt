<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SafeModel extends Model
{
    //
}
