<?php $__env->startSection('topstyle'); ?>

<style>

.form_special{
    width:50%;
    margin:0 auto;
    
    text-align:center;
}





@media  only screen and (max-width: 767px){
    .form_special{
    width:70%;
    }

}

</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
<a href="<?php echo e(route('boss_main_screen')); ?>"><button class="btn btn-secondary">Späť</button></a><br><br>     
       <h2>Zmena hesla riaditeľa</span></h2><br> 





       <?php if(session('bad_old_pass')): ?>

<div class="alert alert-dark" role="alert">
   Staré heslo nie je správne!

</div>

<?php endif; ?>



<?php if(session('not_match_pass')): ?>

<div class="alert alert-dark" role="alert">
   Nové heslo nie je zopakované správne!

</div>

<?php endif; ?>


<form method="POST" id='form_pilot' class="form_special" action="<?php echo e(route('boss.change_password_post')); ?>">

<?php echo csrf_field(); ?>
    <!-- meno part -->
       <p> Staré heslo* : 
       
            <input type="password" id='oldpass_field' class="form-control" placeholder="Staré heslo" name="old_pass">
       
       
       
       </p>



       <p> Nové heslo* : 
       
       <input type="password" id='newpass_field' class="form-control" placeholder="Nové heslo" name="new_pass">
  
  </p>




  <p> Zopakujte nové heslo* : 
       
       <input type="password"  id="newpass2_field" class="form-control" placeholder="Zopakujte nové heslo" name="new_pass2">
  
  </p>



  <input type="hidden" name="email" value="<?php echo e(Auth::user()->email); ?>">



  <button id='submit_button' class="btn btn-secondary">Zmeniť heslo</button>




</form>
      
<br>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('subscripts'); ?>

<script>

$(document).ready(function() {
    $('#submit_button').click(function(){

         event.preventDefault();
             let oldpass = $("#oldpass_field").val();
             let newpass = $("#newpass_field").val();
             let newpass2 = $("#newpass2_field").val();


          if(oldpass == '' || newpass == '' || newpass2 == ''){
             alert('Vyplňte všetky povinné polia označené *');
          }else{
               document.getElementById('form_pilot').submit();
          }

         


    });
});

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/7/2/72c3dfec-5ff6-4a5a-a262-83fc1b4b1483/airpass.site/airpass/resources/views/boss/change_password.blade.php ENDPATH**/ ?>