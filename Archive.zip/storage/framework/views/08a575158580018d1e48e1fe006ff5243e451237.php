<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:175px;
}

.hover_pilot{
    text-decoration:none;
    color:#636b6f;
}

.hover_pilot:visited{
    color:#636b6f;
}

.hover_pilot:hover{
    font-weight:900;
    color:#636b6f;
}


.form_special{
    width:50%;
    margin:0 auto;
    
    text-align:center;
}





@media  only screen and (max-width: 767px){
    .form_special{
    width:70%;
    }

}


</style>







<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
<a href="<?php echo e(route('boss_main_screen')); ?>"><button class="btn btn-secondary">Späť</button></a><br><br>     



<?php if(session('absolvent_added')): ?>

        <div class="alert alert-dark" role="alert">
           Absolvent pridaný

        </div>

        <?php endif; ?>



        <?php if(session('absolvent_updated')): ?>

        <div class="alert alert-dark" role="alert">
           Absolvent aktualizovaný

        </div>

        <?php endif; ?>



        <?php if(session('absolvent_deleted')): ?>

        <div class="alert alert-dark" role="alert">
           Absolvent zmazaný

        </div>

        <?php endif; ?>



       
        
        <div style='text-align:center'><a href="<?php echo e(route('boss.add_absolvent')); ?>">
        <button class="btn btn-secondary">Pridať absolventa</button></a></div><br>
           

       <h2>Zoznam absolventov</h2><br>


<style>

.sub_box{
  border-bottom: 1px solid #d3d6d8;
  border-left: 1px solid #d3d6d8;
  border-right: 1px solid #d3d6d8;
  margin-bottom:20px;
  padding:10px;
  display:none;
  position:relative;
}

.preukaz_box{
  cursor:pointer;
}


.preukaz_plus{
  display:inline-block;color:#6c757d;position:absolute;top:17px;right:10px;
}

.preukaz_minus{
  display:none;color:#6c757d;position:absolute;top:17px;right:10px;
}




.delete_preu_button{
position:absolute;
bottom:10px;
right:20px;
    }




.delete_preu_button_m{
    display:none;
}


@media  only screen and (max-width: 767px){
    .sub_box{
    padding-bottom:75px;

    }
    
    
    
    .delete_preu_button{
    display:none;
        }


    .delete_preu_button_m{
     display:block;
        text-align:center;
        margin-top:20px;
    }
    
    
    .form_special p{
        width:100% !important;
    }

}

</style>

       <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  




    <div class="preukaz_upper_box">



       <div class="alert alert-secondary preukaz_box" data-id="<?php echo e($ticket->id); ?>" style="margin-bottom:0;position:relative" role="alert" id="preukaz_box_<?php echo e($ticket->id); ?>">
  <?php echo e($ticket->f_name); ?> <?php echo e($ticket->l_name); ?> 
  
  <span class="preukaz_plus" id="preukaz_plus_<?php echo e($ticket->id); ?>"><i class="fa fa-plus"></i></span>
  <span class="preukaz_minus" id="preukaz_minus_<?php echo e($ticket->id); ?>"><i class="fa fa-minus"></i></span>

  
  
      </div>



      <div class="sub_box" id="preukaz_sub_box_<?php echo e($ticket->id); ?>">


      <form method="POST" action="<?php echo e(route('boss.delete_absolvent_post')); ?>" id="delete_preukaz_<?php echo e($ticket->id); ?>">
      <?php echo csrf_field(); ?>
<input type="hidden" name="to_del" value="<?php echo e($ticket->id); ?>">
      </form>




<div class="delete_preu_button">
<button onclick="event.preventDefault();document.getElementById('delete_preukaz_<?php echo e($ticket->id); ?>').submit();" class="btn btn-danger "><i class="fa fa-times"></i> Odstrániť</button>
</div>






        
  


  
<form method="POST" id='form_pilot' class="form_special" action="<?php echo e(route('boss.update_absolvent_post')); ?>">

<?php echo csrf_field(); ?>
    


<p style="width:40%;display:inline-block"> Meno:
       
       <input type="text" class="form-control" value="<?php echo e($ticket->f_name); ?>" name="f_name">
  
  </p>



  <p style="width:40%;display:inline-block"> Priezvisko:
       
       <input type="text" class="form-control" value="<?php echo e($ticket->l_name); ?>" name="l_name">
  
  </p>




  <p style="width:40%;display:inline-block"> Telefón:
       
       <input type="text" class="form-control" value="<?php echo e($ticket->phone_num); ?>" name="phone">
  
  </p>



  <p style="width:40%;display:inline-block"> Email:
       
       <input type="text" class="form-control" value="<?php echo e($ticket->email); ?>" name="email">
  
  </p>




  <input type="hidden" name="to_upd" value="<?php echo e($ticket->id); ?>">

 


  <br>

  <button id='submit_button' class="btn btn-secondary">Uložiť</button>




</form>


<div class="delete_preu_button_m">
<button onclick="event.preventDefault();document.getElementById('delete_preukaz_<?php echo e($ticket->id); ?>').submit();" class="btn btn-danger "><i class="fa fa-times"></i> Odstrániť</button>
</div>
      
      </div>



    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<br>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('subscripts'); ?>

<script>

$(".preukaz_box").click(function(){

    var id=$(this).data('id');

    if($("#preukaz_sub_box_"+id).is(':visible')){
      $(".sub_box").slideUp();

      $(this).children('.preukaz_plus').show();
      $(this).children('.preukaz_minus').hide();


    }else{
      $(".sub_box").slideUp();
      $(".preukaz_minus").hide();
      $(".preukaz_plus").show();
      
      $(this).children('.preukaz_plus').hide();
      $(this).children('.preukaz_minus').show();
$("#preukaz_sub_box_"+id).slideDown();

    }

    


});


</script>


<script>
$( ".platnost_sep" ).datepicker({dateFormat: "dd-mm-yy"});
$( ".platnost_mep" ).datepicker({dateFormat: "dd-mm-yy"});
$( ".platnost_z137t" ).datepicker({dateFormat: "dd-mm-yy"});
$( ".platnost_fi" ).datepicker({dateFormat: "dd-mm-yy"});
$( ".platnost_zdrav1" ).datepicker({dateFormat: "dd-mm-yy"});
$( ".platnost_zdrav2" ).datepicker({dateFormat: "dd-mm-yy"});
$( ".platnost_radio" ).datepicker({dateFormat: "dd-mm-yy"});
</script>



<script>


$(".radio_class").change(function(){


  if($(this).val()==1){
    $(this).parent().siblings('p').children('.radio_type, .radio_num, .radio_unl').prop("disabled", false);

    if($(this).parent().siblings('p').children('.radio_unl').val()==1){
      $(this).parent().siblings('p').children('.platnost_radio').prop("disabled", true);
    }else{
      $(this).parent().siblings('p').children('.platnost_radio').prop("disabled", false);
    }
    
  }else{
    $(this).parent().siblings('p').children('.radio_type, .radio_num, .radio_unl, .platnost_radio').prop("disabled", true);
  }

  


});

</script>




<script>


$( ".radio_unl" ).change(function() {
 
 let val=$(this).val();

 if(val==1){
  $(this).parent().siblings('p').children('.platnost_radio').prop('disabled', true);
    
 }else if(val==2){
  $(this).parent().siblings('p').children('.platnost_radio').prop('disabled', false);
 }

});


</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/7/2/72c3dfec-5ff6-4a5a-a262-83fc1b4b1483/airpass.site/airpass/resources/views/boss/show_absolvents.blade.php ENDPATH**/ ?>