<?php $__env->startSection('topstyle'); ?>


<style>
#form_main{
    width:50%;
    margin:0 auto;
    display:none;
    text-align:center;
}


#choose_role_div{
    display:none;
}


#choose_role_div .btn{
    width:100px;
}


@media  only screen and (max-width: 767px){
    #form_main{
    width:70%;
    }

}


</style>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            <div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>



                <div style="text-align:center">

                <a href="<?php echo e(route('choose_login')); ?>"><button id="prihlasenie_trigger" class="btn btn-secondary">Prihlásenie</button></a>

                </div>



                

                




                    
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/main_login.blade.php ENDPATH**/ ?>