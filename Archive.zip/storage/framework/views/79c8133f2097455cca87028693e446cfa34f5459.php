


<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:150px;
}

</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
<a href="<?php echo e(route('boss_all_ziaci')); ?>"><button style="width:220px" class="btn btn-secondary"><i class="fa fa-users" aria-hidden="true"></i> Späť na všetkých žiakov</button></a><br><br>     
       <h2>Žiak <span id="f_name_head"><?php echo e($pilot->f_name); ?></span> <span id="l_name_head"><?php echo e($pilot->l_name); ?></span></h2><br> 


    <!-- meno part -->
       <p> Meno: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="f_name" type="text" class="input_change" name="f_name"
       
       value="<?php echo e($pilot->f_name); ?>"
       
        style="display:none">

        <span data-label="f_name" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change"><?php echo e($pilot->f_name); ?></span> </span>
       
       
       
       </p>



       <!-- priezvisko part -->


       <p> Priezvisko: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="l_name" type="text" class="input_change" name="l_name"
       
       value="<?php echo e($pilot->l_name); ?>"
       
        style="display:none">

        <span data-label="l_name" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change"><?php echo e($pilot->l_name); ?></span> </span>
       
       
       
       </p>

<!-- rod_cislo part -->


<p> Rodné číslo: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="rod_cislo" type="text" class="input_change" name="rod_cislo"
       
       value="<?php echo e($pilot->rod_cislo); ?>"
       
        style="display:none">

        <span data-label="rod_cislo" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       
       <?php if($pilot->rod_cislo==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->rod_cislo); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>
       
       <!-- datum_narodenia part -->


<p> Dátum narodenia: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="dat_nar" type="text" class="input_change" name="dat_nar"
       
       value="<?php echo e($pilot->dat_nar); ?>"
       
        style="display:none">

        <span data-label="dat_nar" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change"> 
        <?php if($pilot->dat_nar==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->dat_nar); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>
       
       <!-- ulica part -->


<p> Ulica: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="ulica" type="text" class="input_change" name="ulica"
       
       value="<?php echo e($pilot->ulica); ?>"
       
        style="display:none">

        <span data-label="ulica" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       <?php if($pilot->ulica==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->ulica); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>
       
       <!-- c_ulice part -->


<p> Číslo domu: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="c_ulice" type="text" class="input_change" name="c_ulice"
       
       value="<?php echo e($pilot->c_ulice); ?>"
       
        style="display:none">

        <span data-label="c_ulice" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       
       <?php if($pilot->c_ulice==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->c_ulice); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>

       <!-- city part -->


<p> Mesto: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="city" type="text" class="input_change" name="city"
       
       value="<?php echo e($pilot->city); ?>"
       
        style="display:none">

        <span data-label="city" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       
       <?php if($pilot->city==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->city); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>

         <!-- psc part -->


<p> PSČ: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="psc" type="text" class="input_change" name="psc"
       
       value="<?php echo e($pilot->psc); ?>"
       
        style="display:none">

        <span data-label="psc" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       
       <?php if($pilot->psc==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->psc); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>

 <!-- phone_1 part -->


<p> Telefón1: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="phone_1" type="text" class="input_change" name="phone_1"
       
       value="<?php echo e($pilot->phone_1); ?>"
       
        style="display:none">

        <span data-label="phone_1" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       
       
       <?php if($pilot->phone_1==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->phone_1); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>

        <!-- phone_2 part -->


<p> Telefón2: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="phone_2" type="text" class="input_change" name="phone_2"
       
       value="<?php echo e($pilot->phone_2); ?>"
       
        style="display:none">

        <span data-label="phone_2" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       
       <?php if($pilot->phone_2==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->phone_2); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>

        <!-- email part -->


<p> Email: <span class="to_change" style="cursor:pointer">
       
       
       
       <input data-label="email" type="text" class="input_change" name="email"
       
       value="<?php echo e($pilot->email); ?>"
       
        style="display:none">

        <span data-label="email" class="save_input" style="display:none">Uložiť</span>
       
       
       
       <span class="text_change">
       
       <?php if($pilot->email==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->email); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>





<form method="POST" action="<?php echo e(route('boss_one_pilot_delete',['id'=>$pilot->id])); ?>">


<?php echo csrf_field(); ?>
       <button class="btn btn-danger"><i class="fa fa-user-times"></i> Zmazať žiaka</button>
</form>


       <form method="POSt" id="hit_form">
        <?php echo csrf_field(); ?>


       </form>
      
<br>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('subscripts'); ?>

<script>

$(document).ready(function(){

    $(".text_change").click(function(){
    $(this).hide();
    $(this).siblings(".input_change").show();
    $(this).siblings(".save_input").show();
});








$(".save_input").click(function(){
    
    var changed_val=$(this).siblings(".input_change").first().val();



    $(this).siblings(".text_change").html(changed_val);



    $(this).siblings(".text_change").show();



    $(this).siblings(".input_change").hide();



    $(this).hide();


    let _token   = $('#hit_form').find('input[name=_token]').attr("value");
    let input_which =  $(this).data('label');

    $.ajax({
      url: "<?php echo e(route('boss_update_field')); ?>",
      type:"POST",
      data:{
        what_val: input_which,  
        f_name: changed_val,
        user_id: <?php echo e($pilot->id); ?>,
        _token: _token
      },
      success: function(response)
      {
          //var jsonData = JSON.parse(response);

          
          if (response.success == "1")
          {

             
                console.log('were cool');


                if(input_which=='f_name'){
                    $("#f_name_head").html(changed_val);
                }else if(input_which=='l_name'){
                  $("#l_name_head").html(changed_val);
                }
            
          }
          else
          {
             


            console.log('wrong');



          }
     }
     });






    
});





});


</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/boss/one_ziak.blade.php ENDPATH**/ ?>