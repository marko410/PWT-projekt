<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:150px;
}

</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
<a href="<?php echo e(route('student_main_screen')); ?>"><button style="width:220px" class="btn btn-secondary">Späť</button></a><br><br>     
       <h2>Preukazy</h2><br> 






       <?php if($preukaz==NULL): ?>


<p>Nemáte žiadne preukazy.</p>


       <?php else: ?>


      
       <p> 
       <strong>Typ preukazu: </strong> 
       <?php if($preukaz->preukaz_type!==NULL): ?>
       <?php echo e($preukaz->preukaz_type); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <p> 
       <strong>Číslo preukazu: </strong> 
       <?php if($preukaz->preukaz_num!==NULL): ?>
       <?php echo e($preukaz->preukaz_num); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <p> 
       <strong>SEP: </strong> 
       <?php if($preukaz->sep==1): ?>
       Áno
        <?php elseif($preukaz->sep==2): ?>
        Nie
        <?php else: ?>
        -
        <?php endif; ?>
       </p>




       <p> 
       <strong>Platnosť SEP do: </strong> 
       <?php if($preukaz->sep_to!==NULL): ?>
       <?php echo e($preukaz->sep_to); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <p> 
       <strong>MEP: </strong> 
       <?php if($preukaz->mep==1): ?>
       Áno
        <?php elseif($preukaz->mep==2): ?>
        Nie
        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <p> 
       <strong>Platnosť MEP do: </strong> 
       <?php if($preukaz->mep_to!==NULL): ?>
       <?php echo e($preukaz->mep_to); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <p> 
       <strong>Z137T: </strong> 
       <?php if($preukaz->z137t==1): ?>
       Áno
        <?php elseif($preukaz->z137t==2): ?>
        Nie
        <?php else: ?>
        -
        <?php endif; ?>
       </p>






       <p> 
       <strong>Platnosť Z137T do: </strong> 
       <?php if($preukaz->z137t_to!==NULL): ?>
       <?php echo e($preukaz->z137t_to); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>








       <p> 
       <strong>FI: </strong> 
       <?php if($preukaz->fi==1): ?>
       Áno
        <?php elseif($preukaz->fi==2): ?>
        Nie
        <?php else: ?>
        -
        <?php endif; ?>
       </p>






       <p> 
       <strong>Platnosť FI do: </strong> 
       <?php if($preukaz->fi_to!==NULL): ?>
       <?php echo e($preukaz->fi_to); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>





       <p> 
       <strong>Zdrav. Spôsobilosť 1. : </strong> 
       <?php if($preukaz->zdrav_sp1==1): ?>
       Áno
        <?php elseif($preukaz->zdrav_sp1==2): ?>
        Nie
        <?php else: ?>
        -
        <?php endif; ?>
       </p>






       <p> 
       <strong>Platnosť Zdrav. Spôsobilosť 1. do: </strong> 
       <?php if($preukaz->zdrav_sp1_to!==NULL): ?>
       <?php echo e($preukaz->zdrav_sp1_to); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>




       <p> 
       <strong>Zdrav. Spôsobilosť 2. : </strong> 
       <?php if($preukaz->zdrav_sp2==1): ?>
       Áno
        <?php elseif($preukaz->zdrav_sp2==2): ?>
        Nie
        <?php else: ?>
        -
        <?php endif; ?>
       </p>






       <p> 
       <strong>Platnosť Zdrav. Spôsobilosť 2. do: </strong> 
       <?php if($preukaz->zdrav_sp2_to!==NULL): ?>
       <?php echo e($preukaz->zdrav_sp2_to); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>


       <p> 
       <strong>Preukaz rádiofonistu : </strong> 
       <?php if($preukaz->radio_has==1): ?>
       Áno
        <?php elseif($preukaz->radio_has==2): ?>
        Nie
        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <p> 
       <strong>Typ preukazu rádiofonistu : </strong> 
       <?php if($preukaz->radio_type!==NULL): ?>
       <?php echo e($preukaz->radio_type); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>




       <p> 
       <strong>Číslo preukazu rádiofonistu : </strong> 
       <?php if($preukaz->radio_num!==NULL): ?>
       <?php echo e($preukaz->radio_num); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>




       <p> 
       <strong>Platnosť preukazu rádiofonistu : </strong> 
       <?php if($preukaz->radio_unl==1): ?>
       Neobmedzená
        <?php elseif($preukaz->radio_unl==2): ?>
        Obmedzená
        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <?php if($preukaz->radio_unl==2): ?>
       <p> 
       <strong>Platnosť preukazu rádiofonistu do: </strong> 
       <?php if($preukaz->radio_to!==NULL): ?>
       Neobmedzená
        <?php echo e($preukaz->radio_to); ?>

        <?php else: ?>
        -
        <?php endif; ?>
       </p>



       <?php endif; ?>





       
       
       






       <?php endif; ?>


<br>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('subscripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ondrejsmerek/Desktop/Laravel/resources/views/ziak/preukaz.blade.php ENDPATH**/ ?>