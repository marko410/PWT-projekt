


<?php $__env->startSection('topstyle'); ?>


<style>


#form_main{
    width:50%;
    margin:0 auto;
    }


@media  only screen and (max-width: 767px){
    #form_main{
    width:70%;
    }

}


</style>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            <div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>



                
                <?php if(session('bad_credentials')): ?>

<div class="alert alert-danger" role="alert">
    Nesprávne prihlasovacie údaje.

</div>

<?php endif; ?>


<?php if(session('no_role')): ?>

<div class="alert alert-danger" role="alert">
    Na danú stránku nemáte právomoci. Prihláste sa ako <?php echo e(session('no_role')); ?>.

</div>

<?php endif; ?>
                


                <form id="form_main" method="POST" action="<?php echo e(route('main_screen_login_post')); ?>">
                <div class="links">

                
                <br>


                    <h2>Prihlásenie  
                        <?php if($id==3): ?>
                                    (riaditeľ)
                        <?php elseif($id==2): ?>
                            (pilot)
                        <?php elseif($id==1): ?>
                            (žiak)
                        

                        <?php endif; ?>
                    </h2> 

                <?php echo csrf_field(); ?>

                <label>Meno</label>    
                <input type="text" name="name" class="form-control"><br>

                <label>Heslo</label>    
                <input type="password" name="password" class="form-control">
                <input type="hidden" name="who" class="form-control" value="<?php echo e($id); ?>">
                <br>

                <button type="submit" class="btn btn-secondary">Prihlásiť</button>

                

               <br>


               
                </form>
       
                    
                </div>

                <br><br>
                <a href="<?php echo e(route('choose_login')); ?>"><button class="btn btn-secondary" id="go_back_choose_role">Späť</button></a>
            </div>
        </div>
         
<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ondrejsmerek/Desktop/Laravel/resources/views/login_form_screen.blade.php ENDPATH**/ ?>