


<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:150px;
}

</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>



                
                <?php if(session('pass_change_good')): ?>

<div class="alert alert-dark" role="alert">
   Heslo úspešne zmenené!

</div>

<?php endif; ?>

<div id="choose_role_div" style="text-align:center">
        
        <br>
        <a href="<?php echo e(route('pilot_preukaz')); ?>"><button class="btn btn-secondary">Preukazy</button></a><br><br>
        <a href="<?php echo e(route('pilot_ziaci')); ?>"><button class="btn btn-secondary">Moji žiaci</button></a><br><br>
        <a href="<?php echo e(route('pilot_osobne_udaje')); ?>"><button class="btn btn-secondary">Osobné údaje</button></a><br><br>


        
        


        <a href="<?php echo e(route('pilot_zmena_hesla')); ?>"><button class="btn btn-secondary">Zmena hesla</button></a><br><br>


        <p><span style="cursor:pointer" onclick="event.preventDefault();document.getElementById('logout_form').submit();" id="logout_btn"><strong>Odhlásiť sa</strong></span></p>
        <form id="logout_form" style="display:none" action="<?php echo e(route('pilot_logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>

        </form>

        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ondrejsmerek/Desktop/Laravel/resources/views/pilot/main_screen.blade.php ENDPATH**/ ?>