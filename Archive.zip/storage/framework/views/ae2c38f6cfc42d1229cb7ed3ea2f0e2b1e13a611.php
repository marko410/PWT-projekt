<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:150px;
}

</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>
 

<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
<a href="<?php echo e(route('pilot_ziaci')); ?>"><button style="width:220px" class="btn btn-secondary"><i class="fa fa-users" aria-hidden="true"></i> Späť na všetkých žiakov</button></a><br><br>     
       <h2>Žiak <span id="f_name_head"><?php echo e($pilot->f_name); ?></span> <span id="l_name_head"><?php echo e($pilot->l_name); ?></span></h2><br> 


    <!-- meno part -->
       <p> Meno: <span class="to_change" style="cursor:pointer">
       
       
       
       
       <span class="text_change"><?php echo e($pilot->f_name); ?></span> </span>
       
       
       
       </p>



       <!-- priezvisko part -->


       <p> Priezvisko: <span class="to_change" style="cursor:pointer">
       
       
       
       
       <span class="text_change"><?php echo e($pilot->l_name); ?></span> </span>
       
       
       
       </p>

<!-- rod_cislo part -->


<p> Rodné číslo: <span class="to_change" style="cursor:pointer">
       
       
       
      
       
       
       <span class="text_change">
       
       <?php if($pilot->rod_cislo==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->rod_cislo); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>
       
       <!-- datum_narodenia part -->


<p> Dátum narodenia: <span class="to_change" style="cursor:pointer">
       
       
   
       
       <span class="text_change"> 
        <?php if($pilot->dat_nar==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->dat_nar); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>
       
       <!-- ulica part -->


<p> Ulica: <span class="to_change" style="cursor:pointer">
       
       
    
       
       
       <span class="text_change">
       <?php if($pilot->ulica==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->ulica); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>
       
       <!-- c_ulice part -->


<p> Číslo domu: <span class="to_change" style="cursor:pointer">
       
       
       
   
       
       <span class="text_change">
       
       <?php if($pilot->c_ulice==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->c_ulice); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>

       <!-- city part -->


<p> Mesto: <span class="to_change" style="cursor:pointer">
       
       

       
       <span class="text_change">
       
       <?php if($pilot->city==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->city); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>

         <!-- psc part -->


<p> PSČ: <span class="to_change" style="cursor:pointer">
       
       
       
  
       
       <span class="text_change">
       
       <?php if($pilot->psc==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->psc); ?>


       <?php endif; ?>
       
       
       </span> </span>
       
  
       
       </p>

 <!-- phone_1 part -->


<p> Telefón1: <span class="to_change" style="cursor:pointer">
       
   
       
       <?php if($pilot->phone_1==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->phone_1); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>

        <!-- phone_2 part -->


<p> Telefón2: <span class="to_change" style="cursor:pointer">
       
    
       
       <span class="text_change">
       
       <?php if($pilot->phone_2==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->phone_2); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>

        <!-- email part -->


<p> Email: <span class="to_change" style="cursor:pointer">
       
       
       
      
       
       <span class="text_change">
       
       <?php if($pilot->email==NULL): ?>
-----

       <?php else: ?>
       <?php echo e($pilot->email); ?>


       <?php endif; ?>
       
       </span> </span>
       
  
       
       </p>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('subscripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/7/2/72c3dfec-5ff6-4a5a-a262-83fc1b4b1483/airpass.site/airpass/resources/views/pilot/one_ziak.blade.php ENDPATH**/ ?>