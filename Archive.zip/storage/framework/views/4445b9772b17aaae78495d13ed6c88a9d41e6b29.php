


<?php $__env->startSection('topstyle'); ?>


<style>
#form_main{
    width:50%;
    margin:0 auto;
    
    text-align:center;
}





@media  only screen and (max-width: 767px){
    #form_main{
    width:70%;
    }

}


</style>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
            <div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>




        <?php if(session('no_role')): ?>

        <div class="alert alert-danger" role="alert">
            Na danú stránku nemáte právomoci. Prihláste sa ako <?php echo e(session('no_role')); ?>.

        </div>

        <?php endif; ?>



        <?php if(session('bad_credentials')): ?>

<div class="alert alert-danger" role="alert">
    Nesprávne prihlasovacie údaje.

</div>

<?php endif; ?>

           


                <form id="form_main" method="POST" action="<?php echo e(route('main_screen_login_post')); ?>">
                <div class="links">



                    <h2>Prihlásenie</h2> 

                <?php echo csrf_field(); ?>

                <label>Meno</label>    
                <input type="text" name="name" class="form-control"><br>

                <label>Heslo</label>    
                <input type="password" name="password" class="form-control">
                <br>

                <button class="btn btn-secondary">Prihlásiť</button>


                </form>


                    
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/main_login_kick.blade.php ENDPATH**/ ?>