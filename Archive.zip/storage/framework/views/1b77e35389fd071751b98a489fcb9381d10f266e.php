


<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:150px;
}

.hover_pilot{
    text-decoration:none;
    color:#636b6f;
}

.hover_pilot:visited{
    color:#636b6f;
}

.hover_pilot:hover{
    font-weight:900;
    color:#636b6f;
}



</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
<a href="<?php echo e(route('boss_main_screen')); ?>"><button class="btn btn-secondary">Späť</button></a><br><br>     



<?php if(session('pilot_deleted')): ?>

        <div class="alert alert-dark" role="alert">
           Žiak <?php echo e(session('pilot_deleted')); ?> zmazaný!

        </div>

        <?php endif; ?>



        <?php if(session('pilot_added')): ?>

        <div class="alert alert-dark" role="alert">
           Žiak <?php echo e(session('pilot_added')); ?> pridaný!

        </div>

        <?php endif; ?>



       <h2>Zoznam žiakov</h2><br> 
       <?php $__currentLoopData = $all_ziaci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><a class="hover_pilot" href="<?php echo e(route('boss_one_ziak_show',['id'=>$pilot->id])); ?>"><?php echo e($pilot->f_name); ?> <?php echo e($pilot->l_name); ?></p>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ondrejsmerek/Desktop/Laravel/resources/views/boss/all_ziaci.blade.php ENDPATH**/ ?>