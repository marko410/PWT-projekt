


<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:175px;
}

.hover_pilot{
    text-decoration:none;
    color:#636b6f;
}

.hover_pilot:visited{
    color:#636b6f;
}

.hover_pilot:hover{
    font-weight:900;
    color:#636b6f;
}



</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
<a href="<?php echo e(route('boss_main_screen')); ?>"><button class="btn btn-secondary">Späť</button></a><br><br>     



<?php if(session('pilot_deleted')): ?>

        <div class="alert alert-dark" role="alert">
           Pilot <?php echo e(session('pilot_deleted')); ?> zmazaný!

        </div>

        <?php endif; ?>



        <?php if(session('preukaz_added')): ?>

        <div class="alert alert-dark" role="alert">
           Preukaz pridaný!

        </div>

        <?php endif; ?>
        
        <div style='text-align:center'><a href="<?php echo e(route('add_pilot_ticket')); ?>">
        <button class="btn btn-secondary">Pridať nový preukaz</button></a></div><br>
           

       <h2>Zoznam preukazov</h2><br>

       <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  





  <a data-toggle="collapse" href="#preukaz_<?php echo e($ticket->id); ?>" role="button" aria-expanded="false" aria-controls="preukaz_<?php echo e($ticket->id); ?>">
  <div style="width:80%;margin:10px auto">
       
       <div class="alert alert-secondary" role="alert">
  <?php echo e($ticket->user->f_name); ?> <?php echo e($ticket->user->l_name); ?>

</div>
  </a>
  

<div class="collapse" id="preukaz_<?php echo e($ticket->id); ?>">
  <div class="card card-body">
  <?php echo e($ticket->user->f_name); ?> <?php echo e($ticket->user->l_name); ?> OTVORENE
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/boss/show_pilot_tickets.blade.php ENDPATH**/ ?>