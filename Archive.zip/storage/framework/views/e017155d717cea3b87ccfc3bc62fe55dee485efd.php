


<?php $__env->startSection('topstyle'); ?>

<style>

#choose_role_div .btn{
    width:150px;
}

</style>




<?php $__env->stopSection(); ?>





<?php $__env->startSection('content'); ?>


<div class="content">
                <div class="title m-b-md">
                    AIRPASS
                </div>

<div id="choose_role_div" style="text-align:center">
        
        <br>
        <button class="btn btn-secondary">Moje preukazy</button><br><br>
        <button class="btn btn-secondary">Osobné údaje</button><br><br>
        <p><strong>Lektor: </strong><u>Lektor xyz</u></p>


       



        <button class="btn btn-secondary">Zmena hesla</button><br><br>


        <p><span style="cursor:pointer" onclick="event.preventDefault();document.getElementById('logout_form').submit();" id="logout_btn"><strong>Odhlásiť sa</strong></span></p>
        <form id="logout_form" style="display:none" action="<?php echo e(route('student_logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>

        </form>

        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/ziak/main_screen.blade.php ENDPATH**/ ?>